package com.example.barrierfree;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private final int My_PERMISSION_REQUEST_CALL_PHONE = 1001;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 권한 확인, 요청
        int perssionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE);
        if (perssionCheck!= PackageManager.PERMISSION_GRANTED){
            Toast.makeText(this, "권한 승인이 필요합니다.", Toast.LENGTH_LONG).show();
            if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.CALL_PHONE)){
                Toast.makeText(this,"즉시통화를 위해 통화 권한이 필요합니다.", Toast.LENGTH_LONG).show();
            }else{
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE},
                        My_PERMISSION_REQUEST_CALL_PHONE);
                Toast.makeText(this,"즉시통화를 위해 통화 권한이 필요합니다.", Toast.LENGTH_LONG).show();
            }
        }

        // 버튼을 누르면 다른 페이지로 이동
        Button ButtonBollard = (Button) findViewById(R.id.볼라드);
        ButtonBollard.setOnClickListener(new View.OnClickListener(){
             public void onClick(View v){
                 Intent intent1 = new Intent(getApplicationContext(), Bollard.class);
                 startActivity(intent1);
             }
        });

        Button ButtonRequest = (Button) findViewById(R.id.문의);
        ButtonRequest.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                Intent intent2 = new Intent(getApplicationContext(), Request.class);
                startActivity(intent2);
            }
        });

        Button FallPopup = (Button) findViewById(R.id.Popup1);
        FallPopup.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                Intent intent3 = new Intent(MainActivity.this, FallPopup.class);
                startActivity(intent3);
            }
        });


        Button Button1 = (Button) findViewById(R.id.번호설정1);
        Button1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                show(R.id.번호설정1);
            }
        });

        Button Button2 = (Button) findViewById(R.id.번호설정2);
        Button2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                show(R.id.번호설정2);
            }
        });

        Button Button3 = (Button) findViewById(R.id.번호설정3);
        Button3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                show(R.id.번호설정3);
            }
        });
    }


    // 버튼을 누르면 이름과 전화번호를 입력하고 버튼의 text를 이름으로 바꾼다.
    void show(final int 번호){

        AlertDialog.Builder NumSet2 = new AlertDialog.Builder(this);

        NumSet2.setTitle("전화 번호 숫자만 입력하세요.");
        NumSet2.setMessage("전화 번호");
        final EditText PhoneNum = new EditText(this);
        NumSet2.setView(PhoneNum);

        NumSet2.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String PhoneNumber = PhoneNum.getText().toString();

                // 값을 다른 페이지로 넘기기
                // 값만 넘기는 방법은???
                // A번호 설정 후, B번호 설정하면 FallPopup에 A번호 없어진다.
                if(번호 == R.id.번호설정1) {
                    Intent intent = new Intent(getApplicationContext(), FallPopup.class);
                    intent.putExtra("PhoneNumber1", PhoneNumber);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                } else if(번호 == R.id.번호설정2){
                    Intent intent = new Intent(getApplicationContext(), FallPopup.class);
                    intent.putExtra("PhoneNumber2", PhoneNumber);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                } else if(번호 == R.id.번호설정3){
                    Intent intent = new Intent(getApplicationContext(), FallPopup.class);
                    intent.putExtra("PhoneNumber3", PhoneNumber);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                }
            }
        });

        NumSet2.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        NumSet2.show();


        AlertDialog.Builder NumSet1 = new AlertDialog.Builder(this);

        NumSet1.setTitle("이름을 입력하세요.");
        NumSet1.setMessage("이름");
        final EditText name = new EditText(this);
        NumSet1.setView(name);


        NumSet1.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Button button1 = (Button) findViewById(번호);
                String usename = name.getText().toString();
                button1.setText(String.valueOf(usename));

                if(번호 == R.id.번호설정1) {
                    Intent intent = new Intent(getApplicationContext(), FallPopup.class);
                    intent.putExtra("name1", usename);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                } else if(번호 == R.id.번호설정2){
                    Intent intent = new Intent(getApplicationContext(), FallPopup.class);
                    intent.putExtra("name2", usename);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                } else if(번호 == R.id.번호설정3){
                    Intent intent = new Intent(getApplicationContext(), FallPopup.class);
                    intent.putExtra("name3", usename);
                    startActivity(intent);
                    overridePendingTransition(0, 0);
                }
            }
        });

        NumSet1.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        NumSet1.show();


    }

}
