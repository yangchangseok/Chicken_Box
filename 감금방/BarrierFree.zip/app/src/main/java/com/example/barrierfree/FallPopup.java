package com.example.barrierfree;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;

public class FallPopup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_fall_popup);

        Button PhoneCall0 = (Button)findViewById(R.id.응급);
        Button PhoneCall1 = (Button)findViewById(R.id.번호설정1);
        Button PhoneCall2 = (Button)findViewById(R.id.번호설정2);
        Button PhoneCall3 = (Button)findViewById(R.id.번호설정3);

        PhoneCall0.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"));
                try{
                    startActivity(intent);
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });

        Intent intent = getIntent();
        String Name1 = intent.getStringExtra("name1");
        String Name2 = intent.getStringExtra("name2");
        String Name3 = intent.getStringExtra("name3");

        final String PhoneNumber1 = intent.getStringExtra("PhoneNumber1");
        final String PhoneNumber2 = intent.getStringExtra("PhoneNumber2");
        final String PhoneNumber3 = intent.getStringExtra("PhoneNumber3");

        if(Name1 != null){
            PhoneCall1.setText(String.valueOf(Name1));
        }else if(Name2 != null){
            PhoneCall2.setText(String.valueOf(Name2));
        }else if(Name3 != null){
            PhoneCall3.setText(String.valueOf(Name3));
        }

        if(PhoneNumber1 != null){
            PhoneCall1.setOnClickListener(new View.OnClickListener(){
                public void onClick(View view){
                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+PhoneNumber1));
                    try{
                        startActivity(intent);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            });
        }else if(PhoneNumber2 != null){
            PhoneCall2.setOnClickListener(new View.OnClickListener(){
                public void onClick(View view){
                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+PhoneNumber2));
                    try{
                        startActivity(intent);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            });
        }else if(PhoneNumber3 != null){
            PhoneCall3.setOnClickListener(new View.OnClickListener(){
                public void onClick(View view){
                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+PhoneNumber3));
                    try{
                        startActivity(intent);
                    }catch(Exception e){
                        e.printStackTrace();
                    }
                }
            });
        }
    }
}
